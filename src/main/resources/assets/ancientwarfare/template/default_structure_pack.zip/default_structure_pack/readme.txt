Files in this default structure pack are not designed to be directly edited by
users.  If you would like to alter any of the structures in this pack you will
need to extract them into your 
mincraft/config/ancientwarfare/structures/included directory, and additionally
disable loading of the default pack in the AncientWarfareStructures.cfg config
file.

Failure to follow these steps will result in duplicate structures being
loaded, with the last one to load overwriting the first for any given name. 
