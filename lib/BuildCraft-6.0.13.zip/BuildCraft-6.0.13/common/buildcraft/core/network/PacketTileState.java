/**
 * Copyright (c) 2011-2014, SpaceToad and the BuildCraft Team
 * http://www.mod-buildcraft.com
 *
 * BuildCraft is distributed under the terms of the Minecraft Mod Public
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */
package buildcraft.core.network;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import io.netty.buffer.ByteBuf;

public class PacketTileState extends PacketCoordinates {

	private class StateWithId {
		public byte stateId;
		public IClientState state;

		public StateWithId(byte stateId, IClientState state) {
			this.stateId = stateId;
			this.state = state;
		}
	}

	private List<StateWithId> stateList = new LinkedList<StateWithId>();

	/**
	 * Default constructor for incoming packets
	 */
	public PacketTileState() {
	}

	/**
	 * Constructor for outgoing packets
	 * 
	 * @param x
	 *            , y, z - the coordinates the tile to sync
	 */
	public PacketTileState(int x, int y, int z) {
		super(PacketIds.STATE_UPDATE, x, y, z);
		isChunkDataPacket = true;
	}

	@Override
	public int getID() {
		return PacketIds.STATE_UPDATE;
	}

	@Override
	public void readData(ByteBuf data) {
		super.readData(data);
	}

	public void applyStates(ByteBuf data, ISyncedTile tile) throws IOException {
		byte stateCount = data.readByte();
		for (int i = 0; i < stateCount; i++) {
			byte stateId = data.readByte();
			tile.getStateInstance(stateId).readData(data);
			tile.afterStateUpdated(stateId);
		}
	}

	public void addStateForSerialization(byte stateId, IClientState state) {
		stateList.add(new StateWithId(stateId, state));
	}

	@Override
	public void writeData(ByteBuf data) {
		super.writeData(data);
		data.writeByte(stateList.size());
		for (StateWithId stateWithId : stateList) {
			data.writeByte(stateWithId.stateId);
			stateWithId.state.writeData(data);
		}
	}
}
